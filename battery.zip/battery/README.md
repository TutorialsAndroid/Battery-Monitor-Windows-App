# 🔋 BatteryApp

BatteryApp is a simple yet powerful Flutter application designed to monitor your battery status on Windows. It provides real-time battery level updates, charging status notifications, and an option to enable auto-start on system boot.

## 🚀 Features

- ✅ **Real-time Battery Monitoring** - Get accurate battery percentage and charging status.
- ✅ **Runs in background** - App runs in background in system tray that keeps it alive.
- 🔔 **Windows Notifications** - Receive notifications when the battery is low (30%, 10%) or when it reaches 80% while charging.
- ⚡ **Auto-Start on Boot** - Enable or disable auto-start using Windows Registry.
- 🔄 **Auto Refresh** - Updates battery information in every 10 sec.

## 📸 Screenshots

![BatteryApp UI](./screenshot/screen.png)

## 🛠️ Installation

### Prerequisites
- Install [Flutter](https://flutter.dev/docs/get-started/install) (Ensure you have set up Flutter for Windows development)
- Enable Windows desktop support for Flutter

### Steps
1. Clone the repository:
   ```bash
   git clone https://github.com/TutorialsAndroid/BatteryApp-Flutter-Windows.git
   cd BatteryApp-Flutter-Windows
   ```
2. Install dependencies:
   ```bash
   flutter pub get
   ```
3. Run the application:
   ```bash
   flutter run
   ```

## ⚙️ Configuration

To enable auto-start functionality, the app modifies the Windows Registry. If you encounter permission issues, run the app with administrative privileges.

## 📦 Dependencies

The app utilizes the following packages:

- [`battery_plus`](https://pub.dev/packages/battery_plus) - Fetch battery level & charging status
- [`shared_preferences`](https://pub.dev/packages/shared_preferences) - Save user preferences
- [`process_run`](https://pub.dev/packages/process_run) - Execute shell commands for registry modifications
- [`windows_notification`](https://pub.dev/packages/windows_notification) - Display Windows toast notifications

## 💡 Usage

1. Launch the app.
2. View battery percentage and charging status.
3. Enable or disable startup functionality.
4. Receive notifications for battery status alerts.

## 🎯 Roadmap

- [ ] Add dark mode support 🌙
- [ ] Implement customizable notification thresholds 📢
- [ ] Enhance UI with better animations ✨

## 🤝 Contributing

We welcome contributions! Feel free to fork this repository, create a branch, and submit a pull request.

1. Fork the repo
2. Create a new branch (`git checkout -b feature-name`)
3. Commit your changes (`git commit -m 'Add new feature'`)
4. Push to the branch (`git push origin feature-name`)
5. Open a Pull Request

## 📜 License

This project is licensed under the [MIT License](LICENSE).

---

💙 _Made with Flutter_ 🦋

